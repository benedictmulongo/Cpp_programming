#include <iostream>

#include "hello.h"

void hello (const char * name, int count) {
  // TODO
}

std::pair<const char *, int> parse_args (int argc, char * argv[]) {
  // TODO
  return std::make_pair ("TODO", 1);
}
